<?php 
// program for arrays with foreach

//indexed array

$arr= array("shubham","yash","om","mohsin");
print_r($arr);
echo"<br>". $arr[1]."<br>";

foreach($arr as $item){
	echo $item."<br>";
}
echo "<br><br><br>";


// Associative array
$aso_arr = array('name' => "Shubham",'age'=> 23, "id"=>"shubham.kale" );

foreach ($aso_arr as $key => $value) {
	echo $key ."=".$value."<br>";
}
echo "<br><br><br>";


// Multidimentional array
$marks=array(
	array(80,90,100),
	array(75,85,95),
	array(70,75,80)
);
 
for($r=0; $r<count($marks); $r++){
	for($c=0; $c<count($marks[$r]); $c++)
	{
		echo $marks[$r][$c]."   ";
	}
	echo "<br>";
}

 ?>