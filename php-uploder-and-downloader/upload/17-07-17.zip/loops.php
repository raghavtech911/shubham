 <?php
// programs for loops to print 1 to 5

$a = $b = $c = 0;
// while loop
while($a<=5){
echo $a ."<br>";
$a++;
}

echo "<br><br><br><br>";

//for loop
for($b=0; $b<=5; $b++)
{
	echo $b."<br>";
}

echo "<br><br><br><br>";

//do while loop
do{
	echo $c."<br>";
	$c++;
	}while($c<=5);

 ?>
