<?php 
//prints blank array    environment variableS

print_r($_ENV);
 ?>