<?php 
# program to check difference between echo and print

echo "Shubham <br>";  // prints Shubham
print "kale<br>";     // prints kale   

echo "Shubham"."kale<br>";  // prints Shubhamkale
print "Shubham"."kale";     //// prints Shubhamkale

 ?>