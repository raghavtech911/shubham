<?php 

$str="shubham kale";

echo strlen($str);
echo "<br>"; //prints string length
echo str_word_count($str);
echo "<br>"; //count words
echo strrev($str); //string in reverse
echo "<br>";
echo strpos($str,"kale"); //position of kale in string
echo "<br>";

 ?>