<?php 
// program to show switch case

$name="shubham";

switch($name){
	case "shubham":
		echo " Shubham you are smart ;)";
		break;

	case "omprakash":
		echo "OP you are funny (:)";
		break;

	case "yash":
		echo "yash you are sweet :)";
		break;

	default:
		echo "You have no Name";
}
?>
