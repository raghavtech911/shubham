<?php 
// progarm for functions
// gives error
function agecheck($a){
	if($a<19){
		echo "you are teenaged<br>";
		}else {
		echo "you are adult";
		}
}

function agecheck($z,$b,$c)
{
		echo $z;
}

agecheck(10);
?>

