<?php
# program to check global veriables
# it will not take values form a myTest function() if global is not specified.
# and if global is written then the values of x and y inside function does not matter.

$x=5;
$y=10;

function myTest(){
	$x=1;
	$y=2;
	global $x,$y;
	$y=$x+$y;
}

myTest();
echo $y; //give 15 as output
?>