<?php 
#program to check append and concatenation

$x="hi";
$x .="world!";

echo $x."<br>";  // prints hiworld!

$a=10;
$b= 10;

var_dump($a===$b); // prints bool(true)
 ?>