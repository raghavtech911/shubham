<?php 
$arr= array("shubham","yash","om","mohsin");
sort($arr); //simple accending sort
foreach($arr as $item){
	echo $item."<br>";
}
echo "<br><br><br>";
rsort($arr); //in decending order
foreach($arr as $item){
	echo $item."<br>";
}

echo "<br><br><br>";

//sorting by key
$aso_arr = array('name' => "Shubham",'age'=> 23, "id"=>"shubham.kale" );
ksort($aso_arr);
foreach ($aso_arr as $key => $value) {
	echo $key."=".$value."<br>";
}

echo "<br><br><br>";

// sorting by value
$aso_arr = array('name' => "Shubham",'age'=> 23, "id"=>"shubham.kale" );
asort($aso_arr);
foreach ($aso_arr as $key => $value) {
	echo $key ."=".$value."<br>";
}

 ?>